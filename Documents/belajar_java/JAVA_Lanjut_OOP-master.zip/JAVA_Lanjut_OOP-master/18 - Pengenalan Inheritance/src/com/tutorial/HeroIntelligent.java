package com.tutorial;

class HeroIntelligent extends Hero{
    // hampa
}